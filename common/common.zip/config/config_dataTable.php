<?php  
$sql_details = array(
    'user' => 'root',
    'pass' => '',
    'db'   => 'fms_anupama',
    'host' => 'localhost'
);

?>