/*$("#order_reg_forms").validate({
	rules: {
		email: {
			required: true,
			email: true
		},
		Order_date: "required",
		employeeid:"required",
		optradio:"required",
           // email:"required"
       },
       messages: {
       	fname: "Please specify your name",
       	employeeid: "Please specify your Employee id",
       	email: "Please specify your email id",

       }
   });*/