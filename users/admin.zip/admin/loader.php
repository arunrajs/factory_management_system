<style type="text/css">
	
	#loader {
    background: url("../../dist/img/loader.gif") no-repeat scroll center center #FFF;
    position: absolute;
    height: 100%;
    width: 100%;
    z-index: 999;
}
</style>

<div id="loader">
	
<script type="text/javascript">
	//alert("okok")
</script>
</div>