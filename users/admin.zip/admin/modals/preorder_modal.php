  <div class="modal fade" id="preorder_modal">
  <div class="modal-dialog modal-xl">
          <div class="modal-content">
            <div class="modal-header">
              <h4 class="modal-title">Select Previous Similar Order</h4>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div class="modal-body">

            <table id="pre_order_list_tabel" class="table table-striped table-bordered" style="width:100%">
          <thead>
            <tr>
              <th>Ord#</th>
              <th>Date</th>
              <th>Customer</th>
              <th>Product</th>
              <th>Type</th>
              <th>Weight</th>
              <th>Amount</th>
              <th>Size</th>
              <th>Status</th>
              <th>Edit</th>
            </tr>
          </thead>
             <tbody id="pre_order_tableBody">
          
          
        </tbody>
          </table>
            </div>
            <div class="modal-footer justify-content-between">
              <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
              
            </div>
          </div>
          <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
      </div>

<!-- <script>
$(function() {
  alert(1)

});
</script> -->